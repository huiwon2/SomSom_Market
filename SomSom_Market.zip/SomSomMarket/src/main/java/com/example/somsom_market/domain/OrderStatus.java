package com.example.somsom_market.domain;

public enum OrderStatus {
    PROCESSED, CANCEL
}
