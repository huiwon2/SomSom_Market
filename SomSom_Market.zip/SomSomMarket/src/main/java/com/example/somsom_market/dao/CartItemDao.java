package com.example.somsom_market.dao;

import org.springframework.stereotype.Repository;

@Repository

public class CartItemDao {
}
