package com.example.somsom_market.domain;

public enum ShipState {
    PROCESSING, INDELIVERY, DELIVERED
}
