package com.example.somsom_market.controller.SomsomItem;
@SuppressWarnings("serial")
public class NotMatchPasswordException extends RuntimeException{
}
