package com.example.somsom_market.domain;

public enum ItemStatus {
    INSTOCK, ING, SOLDOUT
}
