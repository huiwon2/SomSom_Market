package com.example.somsom_market.controller.SomsomItem;

@SuppressWarnings("serial")
public class ItemNotFoundException extends RuntimeException {
}
