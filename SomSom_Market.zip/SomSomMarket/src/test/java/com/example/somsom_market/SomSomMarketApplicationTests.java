package com.example.somsom_market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SomSomMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
